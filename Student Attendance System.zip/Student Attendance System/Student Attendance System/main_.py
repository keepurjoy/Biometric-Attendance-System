from tkinter import*
from tkinter import ttk
import tkinter
from PIL import Image,ImageTk
from time import strftime
from datetime import datetime
import os
import mysql.connector
from student import Student
from developer import Developer
from chatbot import ChatBot
from train import Train
from face_recognition import Face_Recognition


class Face_Recognition_System:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("Biometric Attendance System")

        
        #1st image
        img1=Image.open(r"C:Images\jis1.jpg")
        img1=img1.resize((520,130),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img1)

        f_lbl=Label(self.root,image = self.photoimg1)
        f_lbl.place(x=0, y=0, width=520, height=100)


        #2nd image
        img2=Image.open(r"Images\facialrecognition.png")
        img2=img2.resize((520,130),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        f_lbl=Label(self.root,image = self.photoimg2)
        f_lbl.place(x=520, y=0, width=520, height=100)


        #3rd image
        img3=Image.open(r"Images\jis1.jpg")
        img3=img3.resize((520,130),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        f_lbl=Label(self.root,image = self.photoimg3)
        f_lbl.place(x=1040, y=0, width=520, height=100)


        #bg image
        img4=Image.open(r"Images\jis3.jpg")
        img4=img4.resize((1540,730),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(img4)

        bg_img=Label(self.root,image = self.photoimg4)
        bg_img.place(x=0, y=100, width=1540, height=730)

        title_lbl = Label(bg_img,text="JIS College Of Engineering Biometric Attendance System", font=("Times New Roman",25,"bold"), bg="white", fg="navy blue")
        title_lbl.place(x=0, y=0, width=1540, height=45)


        #================time=================
        def time():
            string = strftime('%H:%M:%S %p')
            lbl.config(text=string)
            lbl.after(1000,time)

        lbl = Label(title_lbl, font=('times new roman',20,'bold'), bg='white',fg='navy blue')
        lbl.place(x=1335,y=-5,width=210,height=50)
        time()


        #student button
        img5=Image.open(r"Images\student.jpg")
        img5=img5.resize((220,220),Image.ANTIALIAS)
        self.photoimg5=ImageTk.PhotoImage(img5)

        b1=Button(bg_img, image=self.photoimg5,command=self.student_details,cursor="hand2")
        b1.place(x=150, y=300, width=220, height=220)

        b1_1=Button(bg_img, text="Student Details",command=self.student_details, cursor="hand2", font=("Helvetica",20,"bold"), bg="dark blue", fg="white")
        b1_1.place(x=150, y=520, width=220, height=40)


        


        #ChatBot button
        img10=Image.open(r"Images\chatbot.jpg")
        img10=img10.resize((220,220),Image.ANTIALIAS)
        self.photoimg10=ImageTk.PhotoImage(img10)

        b1=Button(bg_img,image = self.photoimg10, cursor="hand2",command=self.chatbot)
        b1.place(x=480, y=300, width=220, height=220)

        b1_1=Button(bg_img, text = "ChatBot", cursor="hand2",command=self.chatbot, font=("Helvetica",20,"bold"), bg="dark blue", fg="white")
        b1_1.place(x=479, y=520, width=220, height=40)


        #Developers button
        img11=Image.open(r"Images\dev.jpg")
        img11=img11.resize((220,220),Image.ANTIALIAS)
        self.photoimg11=ImageTk.PhotoImage(img11)

        b1=Button(bg_img,image = self.photoimg11,command=self.developer_data, cursor="hand2")
        b1.place(x=810, y=300, width=220, height=220)

        b1_1=Button(bg_img, text = "Developers",command=self.developer_data, cursor="hand2", font=("Helvetica",20,"bold"), bg="dark blue", fg="white")
        b1_1.place(x=810, y=520, width=220, height=40)


        #Exit button
        img12=Image.open(r"Images\exit.png")
        img12=img12.resize((220,220),Image.ANTIALIAS)
        self.photoimg12=ImageTk.PhotoImage(img12)

        b1=Button(bg_img,image = self.photoimg12, command=self.iExit, cursor="hand2")
        b1.place(x=1140, y=300, width=220, height=220)

        b1_1=Button(bg_img, text = "Sign Out", cursor="hand2",command=self.iExit, font=("Helvetica",20,"bold"), bg="dark blue", fg="white")
        b1_1.place(x=1140, y=510, width=220, height=40)


    def open_img(self):
        os.startfile("data")

    def iExit(self):
        self.iExit=tkinter.messagebox.askyesno("Exit!","Are You Sure?", parent=self.root)
        if self.iExit>0:
            self.root.destroy()
        else:
            return

        #=================Function button====================
    def student_details(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

    def developer_data(self):
        self.new_window=Toplevel(self.root)
        self.app=Developer(self.new_window)

    def chatbot(self):
        self.new_window=Toplevel(self.root)
        self.app=ChatBot(self.new_window)







if __name__ == "__main__":
    root = Tk()
    obj = Face_Recognition_System(root)
    root.mainloop()